package com.example.kalkulatorbangundatar;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class KeduaFragment extends Fragment {
    private EditText txt_Alas, txt_Tinggi;
    private Button btnHasil;
    private TextView hasil;



    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_kedua, container, false);
        txt_Alas = v.findViewById(R.id.txt_Alas);
        txt_Tinggi = v.findViewById(R.id.txt_Tinggi);
        btnHasil = v.findViewById(R.id.btnHasil);
        hasil =  v.findViewById(R.id.hasil);

        btnHasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nilai1 = txt_Alas.getText().toString();
                String nilai2 = txt_Tinggi.getText().toString();

                if (nilai1.isEmpty()){
                    txt_Alas.setError("Data Tidak Boleh Kosong");
                    txt_Tinggi.requestFocus();
                }else if (nilai2.isEmpty()){
                    txt_Alas.setError("Data Tidak Boleh Kosong");
                    txt_Tinggi.requestFocus();
                }else{
                    Double Alas = Double.parseDouble(nilai1);
                    Double Tinggi = Double.parseDouble(nilai2);

                    double luas = 0.5 * Alas * Tinggi;
                    hasil.setText(String.format("%.2f", luas));
                }
            }
        });

        return v;
    }
}